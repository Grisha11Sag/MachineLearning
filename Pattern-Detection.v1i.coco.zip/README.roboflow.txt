
Pattern-Detection - v1 2022-05-10 6:52pm
==============================

This dataset was exported via roboflow.ai on May 10, 2022 at 3:53 PM GMT

It includes 35 images.
Pattrens are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


